import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { TaskComponent } from './task.component';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DatepickerModule, BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { HttpClientModule } from '@angular/common/http';

import { GrdFilterPipe } from 'src/app/filter/grd-filter.pipe';

import { UserService} from 'src/app/services/user.service';
import { ProjectService} from 'src/app/services/project.service';
import { TaskService} from 'src/app/services/task.service';
import { ParenttaskService} from 'src/app/services/parenttask.service';
import { ApiService } from 'src/app/services/api.service';

import { RouterTestingModule } from '@angular/router/testing';
import { NgxPaginationModule } from 'ngx-pagination';

describe('TaskComponent', () => {
  let component: TaskComponent;
  let fixture: ComponentFixture<TaskComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [FormsModule, ReactiveFormsModule, BsDatepickerModule.forRoot(),
        DatepickerModule.forRoot(), HttpClientModule, RouterTestingModule, NgxPaginationModule],
      declarations: [TaskComponent, GrdFilterPipe],
      providers: [TaskService, UserService, ProjectService,ParenttaskService,ApiService]
    })
      .compileComponents();
  }));


  beforeEach(() => {
    fixture = TestBed.createComponent(TaskComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('task Form invalid when empty', () => {
    expect(component.taskForm.valid).toBeFalsy();
  });

  it('Project name field validity', () => {
    let errors = {};
    let Project = component.taskForm.controls['Project'];
    errors = Project.errors || {};
    expect(errors['required']).toBeTruthy(); 
  });

  it('Task Name field validity', () => {
    let errors = {};
    let TaskName = component.taskForm.controls['TaskName'];
    errors = TaskName.errors || {};
    expect(errors['required']).toBeTruthy(); 
  });

  it('Task Form valid when submitted', () => {
    expect(component.taskForm.valid).toBeFalsy();
    component.taskForm.controls['Project'].setValue("Karma Project");
    component.taskForm.controls['TaskName'].setValue("Karma TaskName");
    component.taskForm.controls['StartDate'].setValue("2018-12-12");
    component.taskForm.controls['EndDate'].setValue("2019-12-12");
    expect(component.taskForm.valid).toBeTruthy();
  });


});