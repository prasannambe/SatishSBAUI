import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { DatepickerModule, BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { GrdFilterPipe } from 'src/app/filter/grd-filter.pipe';
import { NgxPaginationModule } from 'ngx-pagination';

import { UserService} from 'src/app/services/user.service';
import { TaskService } from 'src/app/services/task.service';
import { ApiService } from 'src/app/services/api.service';
import { UserComponent } from './user.component';

import { lstUsers } from 'src/app/mock/mocktasks';
import { of } from 'rxjs';


describe('UserComponent', () => {
  let component: UserComponent;
  let fixture: ComponentFixture<UserComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [FormsModule, ReactiveFormsModule, BsDatepickerModule.forRoot(),
        DatepickerModule.forRoot(), HttpClientModule, NgxPaginationModule],
      declarations: [UserComponent, GrdFilterPipe],
      providers: [TaskService, UserService,ApiService]
    })
      .compileComponents();
      spyOn(UserService.prototype, 'getAll').and.returnValue(of(lstUsers));
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('form invalid when empty', () => {
    expect(component.registerForm.valid).toBeFalsy();
  });

  it('user first name field validity', () => {
    let errors = {};
    let FirstName = component.registerForm.controls['FirstName'];
    errors = FirstName.errors || {};
    expect(errors['required']).toBeTruthy(); 
  });

  it('user last name field validity', () => {
    let errors = {};
    let LastName = component.registerForm.controls['LastName'];
    errors = LastName.errors || {};
    expect(errors['required']).toBeTruthy(); 
  });

  it('employee ID field validity', () => {
    let errors = {};
    let EmployeeId = component.registerForm.controls['EmployeeId'];
    errors = EmployeeId.errors || {};
    expect(errors['required']).toBeTruthy(); 
  });

  it('form valid when submitted', () => {
    expect(component.registerForm.valid).toBeFalsy();
    component.registerForm.controls['FirstName'].setValue("Karma First");
    component.registerForm.controls['LastName'].setValue("Karma Last");
    component.registerForm.controls['EmployeeId'].setValue("1234567890");
    expect(component.registerForm.valid).toBeTruthy();
  });

  it('should get all Users - view', () => {
    component.getAllUsers();    
    expect(component.allUsers).toEqual(lstUsers);
  });


  // it('Should get Delete Users - view', () => {
  //   beforeCount number : component.getAllUsers().count();
  //   component.deleteUser(2);    
  //   afterCount number : component.getAllUsers().count();
  //   expect(afterCount).toEqual(beforeCount-1);
  // });


});