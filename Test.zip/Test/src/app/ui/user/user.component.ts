import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from "@angular/forms";

import { UserService} from 'src/app/services/user.service';
import { User } from 'src/app/models/UserModel';


@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  registerForm: FormGroup;
  submitted = false;
  allUsers: User[];
  buttonCaption: string = "Add User";
  public searchText: string;
  userCount: number = 0;

  constructor(private formBuilder: FormBuilder, private _usersService: UserService) { }

  ngOnInit() {
    this.registerForm = this.formBuilder.group
    ({
      FirstName: ['', Validators.required],
      LastName: ['', [Validators.required]],
      EmployeeId: ['', [Validators.required]],
      UserId: [null],
      ProjectId: [null],
      TaskId: [null]
    });
    this.getAllUsers();
  }
 

  public getAllUsers() {
    
    this._usersService.getAll().subscribe(
      result => {
        this.allUsers = result;
        this.userCount = result.length;
      });
  }

  onSubmit() {
    this.submitted = true;

    if (this.registerForm.invalid)
    {  return; }


    if (this.registerForm.controls['UserId'].value == null || this.registerForm.controls['UserId'].value == '')
    {
     //alert(this.registerForm.controls['EmployeeId'].value );
      this._usersService.create(this.registerForm.value).subscribe(result => {
        alert('User has been Added!');   
        this.getAllUsers();
      });
    }
    else
      this._usersService.update(this.registerForm.value).subscribe(
        result => {
          alert('User has been Updated!');       
          this.getAllUsers();
        });        
    this.buttonCaption = "Add User";
    this.submitted = false;
    this.registerForm.reset();
  }

  Reset() {
    this.registerForm.reset();
    this.submitted = false;
    this.buttonCaption = "Add User";
  }


  editUser(user) {
    this.buttonCaption = "Update User";
    this.registerForm.setValue({
      FirstName: user.FirstName,
      LastName: user.LastName,
      EmployeeId: user.EmployeeId,
      ProjectId: user.ProjectId,
      TaskId: user.TaskId,
      UserId: user.UserId
    })
    window.scroll(0, 0);
  }


  public deleteUser(UserId) {
    
    this._usersService.delete(UserId).subscribe(
      result => {
        alert('User has been Deleted! - UserId : ' +  UserId);        
        this.getAllUsers();
      });
  }



  SortByUser(strType: string) {
    switch (strType) {
      case "firstname":
        this.allUsers.sort((a, b) => a.FirstName.localeCompare(b.FirstName));
        break;
      case "lastname":
        this.allUsers.sort((a, b) => a.LastName.localeCompare(b.LastName));
        break;
      case "employeeid":
        this.allUsers.sort(function (a, b) { return a.EmployeeId - b.EmployeeId });
        break;
    }
  }

  numberOnly(event): boolean 
  {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  get f() {return this.registerForm.controls;}

}
