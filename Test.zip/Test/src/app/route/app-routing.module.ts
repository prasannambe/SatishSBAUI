

import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';


import { UserComponent } from '../ui//user/user.component';
import { ProjectComponent } from '../ui/project/project.component';
import { TaskComponent } from '../ui/task/task.component';
import { ViewtaskComponent } from '../ui/viewtask/viewtask.component';


const routes: Routes = [

  { path: 'project', component: ProjectComponent },
  { path: 'user', component: UserComponent },
  { path: 'viewtask', component: ViewtaskComponent },  
  { path: 'addtask', component: TaskComponent },
  { path: 'addtask/:taskid', component: TaskComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
