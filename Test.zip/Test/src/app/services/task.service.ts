import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { ApiService } from './api.service';
import { Task } from 'src/app/models/TaskModel';


@Injectable({ providedIn: 'root'})


export class TaskService {

  constructor(private apiService: ApiService) { }

  create(task: Task): Observable<any> {
    return this.apiService.post("Task/InsertTask", task);   
  }
  
  update(task: Task): Observable<any> {
    return this.apiService.put("Task/UpdateTask", task);
  }
  
  delete(Id: number) {
    return this.apiService.delete("Task/DeleteTask", new HttpParams().set("id", Id.toString()))
  }
  
  getAll(): Observable<any> {
    return this.apiService.get("Task/GetAllTask")
      .pipe(map((tasks: Array<any>) => tasks.map(T => this.mapTask(T))));
  }
  
  getById(Id: number): Observable<any> {
      return this.apiService.get("Task/GetTaskById", new HttpParams().set("id", Id.toString()))
      .pipe(map(T => this.mapTask(T)));
  } 

  endTask(task: Task): Observable<any> {
    return this.apiService.put("Task/EndTask", task);

  }
  
  private mapTask(task): Task { 
    return {      
      TaskId: task.TaskId,
      ParentTaskId: task.ParentTaskId,
      ProjectId: task.ProjectId,
      TaskName: task.TaskName,
      StartDate: task.StartDate,
      EndDate: task.EndDate,
      Priority: task.Priority,
      Status:task.Status,
      Project: task.Project,
      ParentTask:task.ParentTask,
      UserId: task.UserId,
      UserName: task.UserName,
      isParentTask: task.isParentTask
    };
  
  }
  }
  