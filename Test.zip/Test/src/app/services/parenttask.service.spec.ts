import { HttpClientModule } from '@angular/common/http';
import { TestBed, inject, fakeAsync, tick } from '@angular/core/testing';
import { of } from 'rxjs';

import { ParenttaskService } from './parenttask.service';
import { ApiService } from 'src/app/services/api.service';

describe('ParenttaskService', () => {
  beforeEach(() => TestBed.configureTestingModule({
    imports: [HttpClientModule],
    providers: [ParenttaskService, ApiService]

  }));

  it('should be created', () => {
    const service: ParenttaskService = TestBed.get(ParenttaskService);
    expect(service).toBeTruthy();
  });
});
