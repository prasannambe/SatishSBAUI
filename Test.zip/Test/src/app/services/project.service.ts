  import { Injectable } from '@angular/core';
  import { HttpClient } from '@angular/common/http';
  import { HttpParams } from '@angular/common/http';
  import { Observable } from 'rxjs';
  import { map } from 'rxjs/operators';
  
  import { ApiService } from './api.service';
  import { Project } from 'src/app/models/ProjectModel';
  
  
  @Injectable({ providedIn: 'root'})
  
  export class ProjectService 
  {
  
  constructor(private apiService: ApiService) { }
  
  create(project: Project): Observable<any> {
    return this.apiService.post("Project/InsertProject", project);   
  }
  
  update(project: Project): Observable<any> {
    return this.apiService.put("Project/UpdateProject", project);
  }
  
  delete(ProjectId: number) {
    return this.apiService.delete("Project/DeleteProject", new HttpParams().set("id", ProjectId.toString()))
  }
  
  getAll(): Observable<any> {
    return this.apiService.get("Project/GetAllProject")
      .pipe(map((projects: Array<any>) => projects.map(project => this.mapProject(project))));
  }
  
  getById(ProjectId: number): Observable<any> {
      return this.apiService.get("Project/GetProjectById", new HttpParams().set("id", ProjectId.toString()))
      .pipe(map(project => this.mapProject(project)));
  } 
  
  
  private mapProject(project): Project { 
    return {
      ProjectId: project.ProjectId,
      ProjectName: project.ProjectName,
      StartDate: project.StartDate,
      EndDate: project.EndDate,
      Priority: project.Priority,
      UserId: project.UserId,
      TasksCount: project.TasksCount,
      CompletedTask: project.CompletedTask,
      UserName:project.UserName,        
    };
  
  }
  }
  